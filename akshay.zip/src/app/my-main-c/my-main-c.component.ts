import { Component, OnInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { MyServiceService } from '../my-service.service'
import { DatePipe } from '@angular/common'
import { NgtscCompilerHost } from '@angular/compiler-cli/src/ngtsc/file_system';
import { throttleTime, map, scan } from 'rxjs/operators';

@Component({
  selector: 'app-my-main-c',
  templateUrl: './my-main-c.component.html',
  styleUrls: ['./my-main-c.component.css'],
  providers: [DatePipe]
})
export class MyMainCComponent implements OnInit {

  private apiKey = "439d4b804bc8187953eb36d2a8c26a02"
  cityData: any
  cityName = 'pune';
  myChart: any;

  todaysDate = new Date();
  lat: any // 18.5196,
  lon: any // 73.8553
  weatherIcon: any

  constructor(private _myService: MyServiceService, private datePipe: DatePipe) {

    Chart.register(...registerables);
  }
  
  offset:any
  ngOnInit(): void {
    // console.log(this.todaysDate)
   

  };




  searchMethod(name: any) {
    // console.log(name);
    this._myService.getdataAccotoCity(name).subscribe(val => {
      this.cityData = val;
      console.log(this.cityData)
      this.lat = this.cityData.list[0].coord.lat
      this.lon = this.cityData.list[0].coord.lon
      // console.log(this.lat, this.lon)
      this.getWeatherDetails()


      this.weatherIcon = `http://openweathermap.org/img/wn/${this.cityData.list[0].weather[0].icon}@2x.png`
      // console.log(this.windSpeedIcon)

    })


  }



  weatherAllData: any
  flag = 1;
  getWeatherDetails() {
    // console.log("weather")
    this._myService.getAllWeatherData(this.lat, this.lon).subscribe(data => {
      this.weatherAllData = data
      console.log(this.weatherAllData)
 //for my date and time in other countries 
  this.offset=this.weatherAllData.timezone_offset
 
 

      this.getData()
      this.getLabelData()
      this.dailyTempArrayMethod()
      this.getNextDaysMethod()
      if (this.flag) {
        this.DisplayChart()
        this.flag = 0;
      }
      else {
        this.myChart.destroy();
        this.DisplayChart()
      }

    })
  }

  DisplayChart() {
    this.myChart = new Chart("ChartData", {
      type: 'line',
      data: {
        labels: this.GraphLabel,
        datasets: [{
          label: '# of Votes',
          data: this.GraphData,
          borderColor: 'red',
          borderWidth: 1,
          // position: "top"
        }]
      },
      options: {
        elements: {
          line: {
            tension: 0.2
          }
        }
      }
    });

  }
  dailyTempArray: any[] = []
  userCityName: any
  userCountryName: any
  temprature: any
  feelsLike: any
  descriptions: any
  windSpeed: any
  pressure: any
  humidity: any
  uvi: any
  dewPoint: any
  visibility: any
  getData() {
    this.userCityName = this.cityData.list[0].name
    this.userCountryName = this.cityData.list[0].sys.country
    this.temprature = this.weatherAllData.current.temp
    this.temprature=Math.round(this.temprature)
    this.dewPoint = this.weatherAllData.current.dew_point
    this.visibility = this.weatherAllData.current.visibility
    this.visibility = this.visibility / 1000
    this.visibility = this.visibility.toFixed(1)
  }

  GraphLabel: any[] = [];
  GraphData: any[] = [];
  getLabelData() {
    this.GraphData = [];
    this.GraphLabel = [];
    for (var i = 0; i < this.weatherAllData.hourly.length; i++) {
      this.GraphLabel.push(this.weatherAllData.hourly[i].weather[0].description + " " + this.weatherAllData.hourly[i].wind_speed);
      this.GraphData.push(this.weatherAllData.hourly[i].temp);
    }
  }
  dailyMaxTempArray: any[] = []
  dailyMinTempArray: any[] = []
  dailyTempArrayMethod() {
    this.dailyMaxTempArray = []
    this.dailyMinTempArray = []
    // console.log("length",this.weatherAllData.daily.length)
    for (let i = 0; i < this.weatherAllData.daily.length; i++) {
      this.dailyMaxTempArray.push(Math.round(this.weatherAllData.daily[i].temp.max))
      this.dailyMinTempArray.push(Math.round(this.weatherAllData.daily[i].temp.min))

    }
    console.log(this.dailyMaxTempArray)
    console.log(this.dailyMinTempArray)

  }

  max: any
  min: any
  desc:any
  dIcon:any
  temp: Date[] = [];
  getNextDaysMethod() {

    // this.nextDaysArray=[]
    // for (var i = 0; i < this.weatherAllData.daily.length; i++) {
    //   var temp=new Date(this.weatherAllData.daily[i].dt*1000)

    //   this.nextDaysArray.push(temp)
    // }
    // console.log(this.nextDaysArray)

    console.log(this.weatherAllData.daily)

    this.weatherAllData.daily.map((info: any) => {
      this.temp.push(new Date(info.dt * 1000))
      this.max = Math.round(info.temp.max)
      this.min = Math.round(info.temp.min)
      this.desc=info.weather[0].description
      this.dIcon=info.weather[0].icon
      this.dIcon=`http://openweathermap.org/img/w/${this.dIcon}.png`

    })

    console.log(this.temp)
  }

    tog=true
  togMethod(){
  this.tog=!this.tog
  }


}
